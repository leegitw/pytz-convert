

TIMEZONE_NAMES_PREFERRED = [
    'Pacific/Midway',  # -1100
    'US/Hawaii',  # -1000
    'US/Alaska',  # -0900
    'US/Pacific',  # -0800
    'US/Mountain',  # -0700
    'US/Central',  # -0600
    'US/Eastern',  # -0500
    'Atlantic/Bermuda',  # -0400
    'Atlantic/Stanley',  # -0300
    'Atlantic/South_Georgia',  # -0200
    'Atlantic/Azores',  # -0100
    'UTC',  # +0000
    'Europe/Berlin',  # +0100
    'Asia/Jerusalem',  # +0200
    'Asia/Qatar',  # +0300
    'Asia/Dubai',  # +0400
    'Asia/Samarkand',  # +0500
    'Asia/Dhaka',  # +0600
    'Asia/Bangkok',  # +0700
    'Asia/Hong_Kong',  # +0800
    'Asia/Tokyo',  # +0900
    'Pacific/Guam',  # +1000
    'Australia/Sydney',  # +1100
    'Pacific/Fiji',  # +1200
    'Pacific/Auckland',  # +1300

    'Pacific/Honolulu',
    'America/Anchorage',
    'America/Los_Angeles',
    'America/Denver',
    'America/Chicago',
    'America/New_York',

    'Europe/Moscow',
    'Asia/Kolkata'
]