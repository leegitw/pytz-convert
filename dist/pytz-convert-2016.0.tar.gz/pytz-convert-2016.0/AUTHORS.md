## pytz-convert Authors
## Timezone conversion functions for Python
===

## pytz-convert Authors
==========================================

We'd like to thank the following people who have contributed to the `pytz-convert` repository.

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>

## pytz-convert-python Maintainers
==========================================

- Jeff Tanner <jefft@tune.com>
- Zaq? Wiedmann <zaq@tune.com>
