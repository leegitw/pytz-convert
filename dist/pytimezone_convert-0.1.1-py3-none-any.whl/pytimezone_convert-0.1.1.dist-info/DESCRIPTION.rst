Timezone conversion functions.
------------------------------

Extension of python package pytz by providing timezone conversion functions.

See https://github.com/TuneLab/pytimezone-convert for more information.


